﻿namespace WindowsFormsApp4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Cell1 = new System.Windows.Forms.Button();
            this.Cell7 = new System.Windows.Forms.Button();
            this.Cell4 = new System.Windows.Forms.Button();
            this.Cell5 = new System.Windows.Forms.Button();
            this.Cell8 = new System.Windows.Forms.Button();
            this.Cell2 = new System.Windows.Forms.Button();
            this.Cell6 = new System.Windows.Forms.Button();
            this.Cell9 = new System.Windows.Forms.Button();
            this.Cell3 = new System.Windows.Forms.Button();
            this.reset = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.xPlayerName = new System.Windows.Forms.TextBox();
            this.oPlayerName = new System.Windows.Forms.TextBox();
            this.xName = new System.Windows.Forms.Label();
            this.oName = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.xScore = new System.Windows.Forms.Label();
            this.yScore = new System.Windows.Forms.Label();
            this.xRadio = new System.Windows.Forms.RadioButton();
            this.yRadio = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Cell1
            // 
            this.Cell1.Location = new System.Drawing.Point(13, 39);
            this.Cell1.Name = "Cell1";
            this.Cell1.Size = new System.Drawing.Size(63, 64);
            this.Cell1.TabIndex = 0;
            this.Cell1.UseVisualStyleBackColor = true;
            this.Cell1.Click += new System.EventHandler(this.Cell1_Click);
            // 
            // Cell7
            // 
            this.Cell7.Location = new System.Drawing.Point(13, 157);
            this.Cell7.Name = "Cell7";
            this.Cell7.Size = new System.Drawing.Size(63, 64);
            this.Cell7.TabIndex = 1;
            this.Cell7.UseVisualStyleBackColor = true;
            this.Cell7.Click += new System.EventHandler(this.Cell7_Click);
            // 
            // Cell4
            // 
            this.Cell4.Location = new System.Drawing.Point(13, 98);
            this.Cell4.Name = "Cell4";
            this.Cell4.Size = new System.Drawing.Size(63, 64);
            this.Cell4.TabIndex = 2;
            this.Cell4.UseVisualStyleBackColor = true;
            this.Cell4.Click += new System.EventHandler(this.Cell4_Click);
            // 
            // Cell5
            // 
            this.Cell5.Location = new System.Drawing.Point(73, 98);
            this.Cell5.Name = "Cell5";
            this.Cell5.Size = new System.Drawing.Size(63, 64);
            this.Cell5.TabIndex = 5;
            this.Cell5.UseVisualStyleBackColor = true;
            this.Cell5.Click += new System.EventHandler(this.Cell5_Click);
            // 
            // Cell8
            // 
            this.Cell8.Location = new System.Drawing.Point(73, 157);
            this.Cell8.Name = "Cell8";
            this.Cell8.Size = new System.Drawing.Size(63, 64);
            this.Cell8.TabIndex = 4;
            this.Cell8.UseVisualStyleBackColor = true;
            this.Cell8.Click += new System.EventHandler(this.Cell8_Click);
            // 
            // Cell2
            // 
            this.Cell2.Location = new System.Drawing.Point(73, 39);
            this.Cell2.Name = "Cell2";
            this.Cell2.Size = new System.Drawing.Size(63, 64);
            this.Cell2.TabIndex = 3;
            this.Cell2.UseVisualStyleBackColor = true;
            this.Cell2.Click += new System.EventHandler(this.Cell2_Click);
            // 
            // Cell6
            // 
            this.Cell6.Location = new System.Drawing.Point(133, 98);
            this.Cell6.Name = "Cell6";
            this.Cell6.Size = new System.Drawing.Size(63, 64);
            this.Cell6.TabIndex = 8;
            this.Cell6.UseVisualStyleBackColor = true;
            this.Cell6.Click += new System.EventHandler(this.Cell6_Click);
            // 
            // Cell9
            // 
            this.Cell9.Location = new System.Drawing.Point(133, 157);
            this.Cell9.Name = "Cell9";
            this.Cell9.Size = new System.Drawing.Size(63, 64);
            this.Cell9.TabIndex = 7;
            this.Cell9.UseVisualStyleBackColor = true;
            this.Cell9.Click += new System.EventHandler(this.Cell9_Click);
            // 
            // Cell3
            // 
            this.Cell3.Location = new System.Drawing.Point(133, 39);
            this.Cell3.Name = "Cell3";
            this.Cell3.Size = new System.Drawing.Size(63, 64);
            this.Cell3.TabIndex = 6;
            this.Cell3.UseVisualStyleBackColor = true;
            this.Cell3.Click += new System.EventHandler(this.Cell3_Click);
            // 
            // reset
            // 
            this.reset.Location = new System.Drawing.Point(227, 38);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(75, 23);
            this.reset.TabIndex = 9;
            this.reset.Text = "Reset";
            this.reset.UseVisualStyleBackColor = true;
            this.reset.Click += new System.EventHandler(this.reset_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(227, 67);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 10;
            this.button11.Text = "Reset Score";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button12.Location = new System.Drawing.Point(227, 97);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 11;
            this.button12.Text = "Undo";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(227, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "X Player Name :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(227, 182);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "O Player Name : ";
            // 
            // xPlayerName
            // 
            this.xPlayerName.Location = new System.Drawing.Point(227, 143);
            this.xPlayerName.Name = "xPlayerName";
            this.xPlayerName.Size = new System.Drawing.Size(75, 20);
            this.xPlayerName.TabIndex = 14;
            this.xPlayerName.Text = "X";
            this.xPlayerName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.xPlayerName.TextChanged += new System.EventHandler(this.xPlayerName_TextChanged);
            // 
            // oPlayerName
            // 
            this.oPlayerName.Location = new System.Drawing.Point(227, 198);
            this.oPlayerName.Name = "oPlayerName";
            this.oPlayerName.Size = new System.Drawing.Size(75, 20);
            this.oPlayerName.TabIndex = 15;
            this.oPlayerName.Text = "O";
            this.oPlayerName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.oPlayerName.TextChanged += new System.EventHandler(this.oPlayerName_TextChanged);
            // 
            // xName
            // 
            this.xName.AutoSize = true;
            this.xName.Location = new System.Drawing.Point(7, 27);
            this.xName.Name = "xName";
            this.xName.Size = new System.Drawing.Size(14, 13);
            this.xName.TabIndex = 16;
            this.xName.Text = "X";
            // 
            // oName
            // 
            this.oName.AutoSize = true;
            this.oName.Location = new System.Drawing.Point(139, 27);
            this.oName.Name = "oName";
            this.oName.Size = new System.Drawing.Size(15, 13);
            this.oName.TabIndex = 17;
            this.oName.Text = "O";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("3ds", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(75, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 40);
            this.label5.TabIndex = 18;
            this.label5.Text = "VS";
            // 
            // xScore
            // 
            this.xScore.AutoSize = true;
            this.xScore.Location = new System.Drawing.Point(32, 51);
            this.xScore.Name = "xScore";
            this.xScore.Size = new System.Drawing.Size(13, 13);
            this.xScore.TabIndex = 19;
            this.xScore.Text = "0";
            // 
            // yScore
            // 
            this.yScore.AutoSize = true;
            this.yScore.Location = new System.Drawing.Point(155, 51);
            this.yScore.Name = "yScore";
            this.yScore.Size = new System.Drawing.Size(13, 13);
            this.yScore.TabIndex = 20;
            this.yScore.Text = "0";
            // 
            // xRadio
            // 
            this.xRadio.AutoSize = true;
            this.xRadio.Checked = true;
            this.xRadio.Location = new System.Drawing.Point(10, 19);
            this.xRadio.Name = "xRadio";
            this.xRadio.Size = new System.Drawing.Size(62, 17);
            this.xRadio.TabIndex = 21;
            this.xRadio.TabStop = true;
            this.xRadio.Text = "X Starts";
            this.xRadio.UseVisualStyleBackColor = true;
            this.xRadio.CheckedChanged += new System.EventHandler(this.xRadio_CheckedChanged);
            // 
            // yRadio
            // 
            this.yRadio.AutoSize = true;
            this.yRadio.Location = new System.Drawing.Point(10, 41);
            this.yRadio.Name = "yRadio";
            this.yRadio.Size = new System.Drawing.Size(63, 17);
            this.yRadio.TabIndex = 22;
            this.yRadio.Text = "O Starts";
            this.yRadio.UseVisualStyleBackColor = true;
            this.yRadio.CheckedChanged += new System.EventHandler(this.yRadio_CheckedChanged_1);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.xName);
            this.groupBox1.Controls.Add(this.oName);
            this.groupBox1.Controls.Add(this.yScore);
            this.groupBox1.Controls.Add(this.xScore);
            this.groupBox1.Location = new System.Drawing.Point(9, 227);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 91);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Score";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.xRadio);
            this.groupBox2.Controls.Add(this.yRadio);
            this.groupBox2.Location = new System.Drawing.Point(217, 227);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(109, 91);
            this.groupBox2.TabIndex = 24;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Start";
            this.groupBox2.MouseHover += new System.EventHandler(this.groupBox2_MouseHover);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(69, 57);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(34, 27);
            this.button1.TabIndex = 23;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(308, 160);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(18, 35);
            this.button2.TabIndex = 25;
            this.button2.Text = "↑↓";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button3.Location = new System.Drawing.Point(305, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(22, 23);
            this.button3.TabIndex = 26;
            this.button3.Text = "X";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(277, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(22, 23);
            this.button4.TabIndex = 27;
            this.button4.Text = "_";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Location = new System.Drawing.Point(-1, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(336, 30);
            this.panel1.TabIndex = 28;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Myriad CAD", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(102, -18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 60);
            this.label3.TabIndex = 28;
            this.label3.Text = "X O";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.button3;
            this.ClientSize = new System.Drawing.Size(332, 325);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.oPlayerName);
            this.Controls.Add(this.xPlayerName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.reset);
            this.Controls.Add(this.Cell6);
            this.Controls.Add(this.Cell9);
            this.Controls.Add(this.Cell3);
            this.Controls.Add(this.Cell5);
            this.Controls.Add(this.Cell8);
            this.Controls.Add(this.Cell2);
            this.Controls.Add(this.Cell4);
            this.Controls.Add(this.Cell7);
            this.Controls.Add(this.Cell1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Opacity = 0.95D;
            this.ShowIcon = false;
            this.Text = "                             X O ";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Cell1;
        private System.Windows.Forms.Button Cell7;
        private System.Windows.Forms.Button Cell4;
        private System.Windows.Forms.Button Cell5;
        private System.Windows.Forms.Button Cell8;
        private System.Windows.Forms.Button Cell2;
        private System.Windows.Forms.Button Cell6;
        private System.Windows.Forms.Button Cell9;
        private System.Windows.Forms.Button Cell3;
        private System.Windows.Forms.Button reset;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox xPlayerName;
        private System.Windows.Forms.TextBox oPlayerName;
        private System.Windows.Forms.Label xName;
        private System.Windows.Forms.Label oName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label xScore;
        private System.Windows.Forms.Label yScore;
        private System.Windows.Forms.RadioButton xRadio;
        private System.Windows.Forms.RadioButton yRadio;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
    }
}

